
Already created for Ubuntu/i386: 

sudo snap install ttimer

Feel free to transform ... 
-------------------------------------------------------------- 


To 'snapcraft' the ttimer two folders, BIN and SNAP, 
and these four files had been used only: 
  - snap/snapcraft.yaml
  - bin/ttimer.desktop
  - bin/icon.png
  - bin/ttimer

The ttimer file is a shell script with a jar file as payload. 

